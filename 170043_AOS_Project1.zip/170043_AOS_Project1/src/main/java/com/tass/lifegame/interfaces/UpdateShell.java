package com.tass.lifegame.interfaces;

public interface UpdateShell {
	public void update();
}
